ExifTool by Phil Harvey (phil at owl.phy.queensu.ca)
----------------------------------------------------------------------------

ExifTool is a customizable set of Perl modules plus a full-featured
application for reading and writing meta information in a wide variety of
files, including the maker note information of many digital cameras by
various manufacturers such as Canon, Casio, FLIR, FujiFilm, GE, HP,
JVC/Victor, Kodak, Leaf, Minolta/Konica-Minolta, Nikon, Olympus/Epson,
Panasonic/Leica, Pentax/Asahi, Phase One, Reconyx, Ricoh, Samsung, Sanyo,
Sigma/Foveon and Sony.

Below is a list of file types and meta information formats currently
supported by ExifTool (r = read, w = write, c = create):

  File Types
  ------------+-------------+-------------+-------------+------------
  3FR   r     | EIP   r     | LA    r     | ORF   r/w   | RSRC  r
  3G2   r     | EPS   r/w   | LNK   r     | OTF   r     | RTF   r
  3GP   r     | ERF   r/w   | M2TS  r     | PAC   r     | RW2   r/w
  ACR   r     | EXE   r     | M4A/V r     | PAGES r     | RWL   r/w
  AFM   r     | EXIF  r/w/c | MEF   r/w   | PBM   r/w   | RWZ   r
  AI    r/w   | EXR   r     | MIE   r/w/c | PCD   r     | RM    r
  AIFF  r     | F4A/V r     | MIFF  r     | PDF   r/w   | SO    r
  APE   r     | FFF   r/w   | MKA   r     | PEF   r/w   | SR2   r/w
  ARW   r/w   | FLA   r     | MKS   r     | PFA   r     | SRF   r
  ASF   r     | FLAC  r     | MKV   r     | PFB   r     | SRW   r/w
  AVI   r     | FLV   r     | MNG   r/w   | PFM   r     | SVG   r
  BMP   r     | FPF   r     | MODD  r     | PGF   r     | SWF   r
  BTF   r     | FPX   r     | MOS   r/w   | PGM   r/w   | THM   r/w
  CHM   r     | GIF   r/w   | MOV   r     | PLIST r     | TIFF  r/w
  COS   r     | GZ    r     | MP3   r     | PICT  r     | TTC   r
  CR2   r/w   | HDP   r/w   | MP4   r     | PMP   r     | TTF   r
  CRW   r/w   | HDR   r     | MPC   r     | PNG   r/w   | VRD   r/w/c
  CS1   r/w   | HTML  r     | MPG   r     | PPM   r/w   | VSD   r
  DCM   r     | ICC   r/w/c | MPO   r/w   | PPT   r     | WAV   r
  DCP   r/w   | IDML  r     | MQV   r     | PPTX  r     | WDP   r/w
  DCR   r     | IIQ   r/w   | MRW   r/w   | PS    r/w   | WEBP  r
  DFONT r     | IND   r/w   | MXF   r     | PSB   r/w   | WEBM  r
  DIVX  r     | INX   r     | NEF   r/w   | PSD   r/w   | WMA   r
  DJVU  r     | ITC   r     | NRW   r/w   | PSP   r     | WMV   r
  DLL   r     | J2C   r     | NUMBERS r   | QTIF  r     | WV    r
  DNG   r/w   | JNG   r/w   | ODP   r     | RA    r     | X3F   r/w
  DOC   r     | JP2   r/w   | ODS   r     | RAF   r/w   | XCF   r
  DOCX  r     | JPEG  r/w   | ODT   r     | RAM   r     | XLS   r
  DV    r     | K25   r     | OFR   r     | RAR   r     | XLSX  r
  DVB   r     | KDC   r     | OGG   r     | RAW   r/w   | XMP   r/w/c
  DYLIB r     | KEY   r     | OGV   r     | RIFF  r     | ZIP   r

  Meta Information
  ----------------------+----------------------+---------------------
  EXIF           r/w/c  |  CIFF           r/w  |  Ricoh RMETA    r
  GPS            r/w/c  |  AFCP           r/w  |  Picture Info   r
  IPTC           r/w/c  |  Kodak Meta     r/w  |  Adobe APP14    r
  XMP            r/w/c  |  FotoStation    r/w  |  MPF            r
  MakerNotes     r/w/c  |  PhotoMechanic  r/w  |  Stim           r
  Photoshop IRB  r/w/c  |  JPEG 2000      r    |  APE            r
  ICC Profile    r/w/c  |  DICOM          r    |  Vorbis         r
  MIE            r/w/c  |  Flash          r    |  SPIFF          r
  JFIF           r/w/c  |  FlashPix       r    |  DjVu           r
  Ducky APP12    r/w/c  |  QuickTime      r    |  M2TS           r
  PDF            r/w/c  |  Matroska       r    |  PE/COFF        r
  PNG            r/w/c  |  GeoTIFF        r    |  AVCHD          r
  Canon VRD      r/w/c  |  PrintIM        r    |  ZIP            r
  Nikon Capture  r/w/c  |  ID3            r    |  (and more)

See html/index.html for more details about ExifTool features.

ExifTool can be downloaded from

  Main server URL:  http://owl.phy.queensu.ca/~phil/exiftool/
  Alternate URL:    http://130.15.24.87/~phil/exiftool/

Note:  Please do not make links to the alternate URL above, because this
server is not permanent.

RUNNING

The exiftool script can be run right away without the need to install
Image::ExifTool.  For example, from within the exiftool directory you can
extract the information from one of the included test files by typing:

  ./exiftool t/images/ExifTool.jpg

If you move the exiftool script to a different directory, you must also
either move the contents of the lib directory or install the Image::ExifTool
package so the script can find the necessary libraries.

Note:  If you are using the Windows cmd shell, you may need to rename
'exiftool' to 'exiftool.pl' to run it directly from the command line.
Alternatively, you can run exiftool with the command 'perl exiftool'.

IF YOU ARE STILL CONFUSED

The exiftool script is a command line application.  You run it by typing
commands in a terminal window.  The first step is to determine the name of
the directory where you downloaded the ExifTool distribution package.
Assuming, for example, you downloaded it to a folder called "Desktop" in
your home directory, then you would type the following commands in a
terminal window to extract and run ExifTool:

  cd ~/Desktop
  gzip -dc Image-ExifTool-#.##.tar.gz | tar -xf -
  cd Image-ExifTool-#.##
  ./exiftool t/images/ExifTool.jpg

Note: You must replace "#.##" in the above commands with the actual version
number of ExifTool that you downloaded.  These commands extract meta
information from one of the test images.  To use one of your images instead,
enter the full path name of your file in place of "t/images/ExifTool.jpg".

INSTALLATION

You can install the Image::ExifTool package to make it available for use by
other Perl scripts by typing the following:

  perl Makefile.PL
  make
  make test
  make install

Notes:
  i) You need root access for the last step above.

  ii) Some Perl installations (like the standard OSX installation) may not
  contain the necessary files to complete the first step above.  But no
  worries:  You can install ExifTool manually by moving 'exiftool' and the
  'lib' directory to any directory in your current PATH (ie. /usr/bin).

  iii) In Windows, "dmake" or "nmake" may be used if "make" is not
  available.  The "nmake" utility may be downloaded from Microsoft at
  http://support.microsoft.com/default.aspx?scid=kb;en-us;Q132084 but note
  that is utility is very old, and may not work with Makefiles generated by
  newer Perl versions.

(Also see html/install.html for more help with installation.)

DEPENDENCIES

Requires Perl version 5.004 or later.  No other special libraries are
required, however the following modules are recommended for decoding
compressed and/or encrypted information from the indicated file types, and
for calculating digest values for some information types:

  Archive::Zip         (ZIP, DOCX, PPTX, XLSX, ODP, ODS, ODT, EIP, iWork)
  Compress::Zlib       (DNG, PNG, PDF, DCM, MIE and SWF files)
  Digest::MD5          (PDF files, IPTC information, and JPG Extended XMP)
  Digest::SHA          (PDF with AES-256 encryption)
  IO::Compress::Bzip2  (RWZ files)
  Win32API::File::Time (enables writing of FileCreateDate in Windows)

COPYRIGHT AND LICENSE

Copyright 2003-2013, Phil Harvey

This is free software; you can redistribute it and/or modify it under the
same terms as Perl itself.

DISTRIBUTION FILES

Below is a list of the files/directories included in the full ExifTool
distribution package:

  Changes                   - Revision history
  ExifTool_config           - Sample run-time configuration file
  MANIFEST                  - Full list of distribution files
  META.yml                  - Standard CPAN dependency file
  Makefile.PL               - Makefile for installation
  README                    - This file
  arg_files/                - Argument files to convert metadata formats:
    exif2iptc.args          - Arguments for converting EXIF to IPTC
    exif2xmp.args           - Arguments for converting EXIF to XMP
    gps2xmp.args            - Arguments for converting GPS to XMP
    iptc2exif.args          - Arguments for converting IPTC to EXIF
    iptc2xmp.args           - Arguments for converting IPTC to XMP
    iptcCore.args           - Complete list of IPTC Core XMP tags
    pdf2xmp.args            - Arguments for converting PDF to XMP
    xmp2exif.args           - Arguments for converting XMP to EXIF
    xmp2gps.args            - Arguments for converting XMP to GPS
    xmp2iptc.args           - Arguments for converting XMP to IPTC
    xmp2pdf.args            - Arguments for converting XMP to PDF
  config_files/             - Sample ExifTool configuration files:
    convert_regions.config  - Config file for converting face regions
  exiftool                  - The exiftool application (Perl script)
  fmt_files/                - Output formatting example files:
    gpx.fmt                 - Format file for creating GPX track
    gpx_wpt.fmt             - Format file for creating GPX waypoints
    kml.fmt                 - Format file for creating KML output files
  html/                     - HTML documentation
  html/TagNames/            - HTML tag name documentation
  lib/                      - ExifTool Perl library modules
  perl-Image-ExifTool.spec  - Red Hat Packaging Manager specification file
  t/                        - Verification test code
  t/images/                 - Verification test images

ADDITIONAL INFORMATION

Read the following files included in the full distribution for more
information:

  html/index.html           - Main ExifTool documentation
  html/install.html         - Installation instructions
  html/history.html         - Revision history
  html/ExifTool.html        - API documentation
  html/TagNames/index.html  - Tag name documentation
  html/geotag.html          - Geotag feature
  html/faq.html             - Frequently asked questions
  html/filename.html        - Renaming/moving files
  html/metafiles.html       - Working with metadata sidecar files
  html/struct.html          - Working with structured XMP information
  lib/Image/ExifTool/README - ExifTool library modules documentation

and if you have installed Image::ExifTool, you can also consult perldoc or
the man pages:

  perldoc exiftool
  perldoc Image::ExifTool
  perldoc Image::ExifTool::TagNames

  man exiftool
  man Image::ExifTool
  man Image::ExifTool::TagNames

Note: If the man pages don't work, it is probably because your man path is
not set to include the installed documentation.  See "man man" for
information about how to set the man path.

----------------------------------------------------------------------------
